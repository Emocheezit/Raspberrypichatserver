from flask import Flask, render_template, request
from flask_socketio import SocketIO, join_room, leave_room, send
import logging

app = Flask(__name__)
app.config['SECRET_KEY'] = 'amazing_secret!' # Updated secret for good measure
socketio = SocketIO(app, cors_allowed_origins="*")

# users maps session id -> {'username': ..., 'room': ...}
users = {}

@app.route('/')
def index():
    return "Private-room chat server. Open /room/<room_name> in your browser to join a private room."

@app.route('/room/<room>')
def room_view(room):
    # Render the same chat page but inject the room name
    return render_template('chat.html', room=room)

@socketio.on('connect')
def handle_connect():
    print(f"[+] Connected: {request.sid}")

@socketio.on('join')
def handle_join(data):
    # data should be {'username': 'Alice', 'room': 'room1'}
    username = data.get('username', 'Anonymous')
    room = data.get('room')
    if not room:
        send("No room provided. Connection refused.", to=request.sid)
        return

    # store user
    users[request.sid] = {'username': username, 'room': room}
    join_room(room)
    
    # SYSTEM Message for all users in the room
    system_msg = f"[system]: Server: *** {username} has joined the room '{room}' ***"
    send(system_msg, room=room)
    print(f"[+] {username} ({request.sid}) joined {room}")

@socketio.on('message')
def handle_message(msg):
    user = users.get(request.sid, {'username': 'Anonymous', 'room': None})
    username = user['username']
    room = user['room']
    
    if room:
        # 1. Send to self (marked as 'self')
        self_msg = f"[self]: {username}: {msg}"
        send(self_msg, to=request.sid)
        
        # 2. Send to others in the room (marked as 'other')
        other_msg = f"[other]: {username}: {msg}"
        socketio.send(other_msg, room=room, skip_sid=request.sid) # skip_sid prevents double-sending to the sender
    else:
        # private message back only to sender
        send("You are not in a room. Please join a room first.", to=request.sid)

@socketio.on('leave')
def handle_leave():
    user = users.pop(request.sid, None)
    if user:
        room = user.get('room')
        username = user.get('username')
        leave_room(room)
        
        # SYSTEM Message for all users in the room
        system_msg = f"[system]: Server: *** {username} has left the room '{room}' ***"
        send(system_msg, room=room)
        print(f"[-] {username} ({request.sid}) left {room}")

@socketio.on('disconnect')
def handle_disconnect():
    user = users.pop(request.sid, None)
    if user:
        room = user.get('room')
        username = user.get('username')
        
        # SYSTEM Message for all users in the room
        system_msg = f"[system]: Server: *** {username} has disconnected from '{room}' ***"
        send(system_msg, room=room)
    print(f"[-] Disconnected: {request.sid}")

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)