from flask import Flask, render_template, request
from flask_socketio import SocketIO, join_room, leave_room, send

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app)

users = {}  # sid -> {'username': ..., 'room': ...}

@app.route('/')
def index():
    return render_template('chat.html')

@socketio.on('connect')
def handle_connect():
    print('[+] New connection')

@socketio.on('disconnect')
def handle_disconnect():
    user = users.get(request.sid)
    if user:
        username = user['username']
        room = user['room']
        print(f"[-] {username} disconnected from {room}")
        send(f"{username} has left the room.", room=room)
        leave_room(room)
        users.pop(request.sid, None)
    else:
        print("[-] Unknown user disconnected")

@socketio.on('join')
def handle_join(data):
    """
    Expected data format: {'username': 'YourName', 'room': 'room1'}
    """
    username = data['username']
    room = data['room']

    users[request.sid] = {'username': username, 'room': room}
    join_room(room)
    send(f"{username} has joined the room: {room}", room=room)
    print(f"[+] {username} joined {room}")

@socketio.on('message')
def handle_message(msg):
    user = users.get(request.sid, {'username': 'Anonymous', 'room': None})
    username = user['username']
    room = user['room']
    if room:
        send(f"{username}: {msg}", room=room)
    else:
        send("You are not in a room. Please join a room first.")

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000)
